import * as React from 'react';
import {View, Text,Button,StyleSheet} from 'react-native';
import AppHeader from './components/AppHeader';
import HomeScreen from './screens/HomeScreen';
import SummaryScreen from './screens/SummaryScreen';
import {createAppContainer, createSwitchNavigator} from
'react-navigator';
export default class App extends React.Component{

  render() {
    return (
      <View>
      <AppHeader/>
      <AppContainer/>
      </View>
    )
  }

}
var AppNavigator = createSwitchNavigator({
  HomeScreen:Homescreen, 
  SummaryScreen:SummaryScreen,
})